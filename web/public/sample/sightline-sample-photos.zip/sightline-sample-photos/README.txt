Sightline sample photos
=======================

20 aerial photos you can submit to a Sightline mission to see what happens when drone photos
land: each is placed on the map from its GPS, altitude and heading, the detector reads it, the
probability map lowers where it looked, and any candidate goes to review.

What they are: photos from the HERIDAL search-and-rescue dataset (CC BY 3.0, see CREDITS.txt),
with a SIMULATED position written into their EXIF/XMP: one east-bound line of a survey over the
Sightline demo area on Mount Seymour, BC (about 49.3699 N, 122.9450 W), 50 m above ground, a photo
every 12 m. Photo SIGHTLINE_f0273.jpg has people in it.

How to use them:
- On the Sightline site: start a live mission at the demo area (last known point 49.37, -122.945),
  then drop the .jpg files on the photo panel (or pick them with the upload button).
- From a terminal, against a Sightline API:
      python -m sightline.client watch <folder with the photos> --api http://127.0.0.1:8000 --mission <id>
- Straight to the API: POST /missions/<id>/photos with up to 50 files (multipart, field "files").

They are a demo, not a real flight: never use them as evidence of where anyone was.
